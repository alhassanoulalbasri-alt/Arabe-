// LexiArabe Pro - Service Worker
// Cache all files for offline use

var CACHE_NAME = 'lexiarabe-v1';
var URLS_TO_CACHE = [
  '/',
  '/index.html',
  '/LexiArabe_Premium_Words.js',
  '/LexiArabe_Premium_Phrases.js',
  '/LexiArabe_Dictionary.js',
  '/LexiArabe_Dictionary_Premium.js',
  '/LexiArabe_Lettres.js'
];

// Install: cache all files
self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(CACHE_NAME).then(function(cache) {
      console.log('Caching app files...');
      return cache.addAll(URLS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Activate: clean old caches
self.addEventListener('activate', function(event) {
  event.waitUntil(
    caches.keys().then(function(cacheNames) {
      return Promise.all(
        cacheNames.filter(function(name) {
          return name !== CACHE_NAME;
        }).map(function(name) {
          return caches.delete(name);
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch: serve from cache, fallback to network
self.addEventListener('fetch', function(event) {
  event.respondWith(
    caches.match(event.request).then(function(response) {
      if (response) {
        return response; // from cache
      }
      return fetch(event.request).then(function(networkResponse) {
        // Cache new files
        if (networkResponse && networkResponse.status === 200) {
          var responseClone = networkResponse.clone();
          caches.open(CACHE_NAME).then(function(cache) {
            cache.put(event.request, responseClone);
          });
        }
        return networkResponse;
      });
    }).catch(function() {
      // Offline fallback
      return caches.match('/index.html');
    })
  );
});
